export const backgrounds = [
  require("../assets/backgrounds/blue.png"),
  require("../assets/backgrounds/child.jpg"),
  require("../assets/backgrounds/stars.jpg"),
  require("../assets/backgrounds/sky.jpg"),
];
